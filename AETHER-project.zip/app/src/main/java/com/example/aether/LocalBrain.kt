package com.example.aether

import android.content.Context
import android.os.BatteryManager
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * The assistant's brain:
 *  1. instant local skills (time, date, battery, memory commands)
 *  2. on-device LLM (MediaPipe LLM Inference, .task model) for everything else
 * Model file: any .task file inside the models folder of the app files directory
 */
class LocalBrain(private val context: Context, private val memory: MemoryStore) {

    private var llm: LlmInference? = null
    private var chatMl = false
    @Volatile private var loading = true

    fun modelFile(): File? {
        val root = File(context.getExternalFilesDir(null) ?: context.filesDir, "models")
        return root.walkTopDown().maxDepth(2).firstOrNull {
            it.isFile && it.extension.equals("task", ignoreCase = true)
        }
    }

    fun hasModelFile(): Boolean = modelFile() != null

    /** Blocking. Returns null on success, else an error message. */
    fun loadLlm(): String? {
        loading = true
        close()
        try {
            val f = modelFile() ?: return "No .task model file found in the models folder."
            val opts = LlmInference.LlmInferenceOptions.builder()
                .setModelPath(f.absolutePath)
                .setMaxTokens(1024)
                .build()
            llm = LlmInference.createFromOptions(context, opts)
            chatMl = f.name.contains("qwen", ignoreCase = true)
            return null
        } catch (t: Throwable) {
            return t.message ?: t.javaClass.simpleName
        } finally {
            loading = false
        }
    }

    fun close() {
        try {
            llm?.close()
        } catch (_: Throwable) {
        }
        llm = null
    }

    fun respond(raw: String): String {
        val q = raw.trim()
        local(q)?.let { return it }

        val engine = llm
        if (engine == null) {
            return if (loading) {
                "I'm still loading my language model. Give me a moment."
            } else {
                "My language model isn't installed yet, so I can only handle the time, date, battery and your saved notes. Check the Setup tab."
            }
        }
        val answer = clean(engine.generateResponse(buildPrompt(q)))
            .ifBlank { "Sorry, I couldn't come up with an answer." }
        memory.addTurn(q, answer)
        return answer
    }

    // ---------------------------------------------------------------- local skills

    private fun local(q: String): String? {
        val n = q.lowercase().replace(Regex("[^a-z0-9' ]"), " ").replace(Regex("\\s+"), " ").trim()
        if (n.isEmpty()) return "I didn't catch that."

        Regex("^(please )?remember (that )?(.+)$", RegexOption.IGNORE_CASE)
            .find(q.trim().trimEnd('.', '!', '?'))?.let {
                memory.addFact(it.groupValues[3])
                return "Noted. I've saved that to memory."
            }

        Regex("^(my name is|call me) (.+)$").find(n)?.let {
            val nm = it.groupValues[2].split(" ").joinToString(" ") { w -> w.replaceFirstChar { c -> c.uppercase() } }
            memory.setUserName(nm)
            return "Understood. I'll call you $nm."
        }

        if (listOf("forget everything", "clear memory", "clear your memory", "delete my memory", "wipe memory")
                .any { n.contains(it) }
        ) {
            memory.clearAll()
            return "Done. My memory has been wiped."
        }

        if (n.contains("what do you remember") || n.contains("what do you know about me") ||
            n.contains("what have i told you")
        ) {
            val f = memory.facts()
            return if (f.isEmpty()) "I don't have any saved notes yet."
            else "Here's what I have. " + f.joinToString(". ") + "."
        }

        if (Regex("^(what('s|s| is) the (current )?time( right now| now)?|what time is it( right now| now)?|tell me the time|current time)$").matches(n)) {
            return "It is " + SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date()) + "."
        }

        if (Regex("^(what('s|s| is) (the |today's |todays )?date( today)?|what day is it( today)?|what('s|s| is) today|today's date)$").matches(n)) {
            return "Today is " + SimpleDateFormat("EEEE, MMMM d", Locale.getDefault()).format(Date()) + "."
        }

        if (n.contains("battery") && n.length < 40) return battery()

        if (n in setOf("who are you", "what are you", "what is your name", "what's your name", "whats your name", "introduce yourself")) {
            return "I'm AETHER, your personal assistant. I run entirely on this device."
        }

        if (n in setOf("hello", "hi", "hey", "hello aether", "hi aether", "hey aether")) {
            return "Hello ${memory.userName()}. What can I do for you?"
        }

        if (n in setOf("thanks", "thank you", "thanks aether", "thank you aether")) return "Anytime."
        if (n in setOf("stop", "cancel", "never mind", "nevermind", "be quiet")) return "Okay."

        return null
    }

    private fun battery(): String {
        val bm = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val pct = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        val suffix = if (bm.isCharging) " and charging" else ""
        return "Battery is at $pct percent$suffix."
    }

    // ---------------------------------------------------------------- LLM prompt

    private fun buildPrompt(q: String): String {
        val name = memory.userName()
        val sys = StringBuilder()
        sys.append("You are AETHER, a calm, concise, professional voice assistant running fully offline on $name's phone. ")
        sys.append("Reply in at most three short sentences of plain spoken English. No markdown, no lists, no emojis.")
        val facts = memory.facts().takeLast(10)
        if (facts.isNotEmpty()) {
            sys.append("\nThings you know about $name: ").append(facts.joinToString("; ")).append(".")
        }
        val turns = memory.recentTurns(3)
        val sb = StringBuilder()
        if (chatMl) {
            sb.append("<|im_start|>system\n").append(sys).append("<|im_end|>\n")
            for (t in turns) {
                sb.append("<|im_start|>user\n").append(t.first.take(200)).append("<|im_end|>\n")
                sb.append("<|im_start|>assistant\n").append(t.second.take(300)).append("<|im_end|>\n")
            }
            sb.append("<|im_start|>user\n").append(q).append("<|im_end|>\n<|im_start|>assistant\n")
        } else {
            sb.append("<start_of_turn>user\n").append(sys).append("\n\n")
            if (turns.isEmpty()) {
                sb.append(q)
            } else {
                sb.append(turns[0].first.take(200)).append("<end_of_turn>\n<start_of_turn>model\n")
                sb.append(turns[0].second.take(300)).append("<end_of_turn>\n")
                for (i in 1 until turns.size) {
                    sb.append("<start_of_turn>user\n").append(turns[i].first.take(200)).append("<end_of_turn>\n")
                    sb.append("<start_of_turn>model\n").append(turns[i].second.take(300)).append("<end_of_turn>\n")
                }
                sb.append("<start_of_turn>user\n").append(q)
            }
            sb.append("<end_of_turn>\n<start_of_turn>model\n")
        }
        return sb.toString()
    }

    private fun clean(s: String): String {
        var t = s.replace("<end_of_turn>", "").replace("<start_of_turn>", "").replace("<|im_end|>", "")
            .replace(Regex("[*#`_]+"), "").replace(Regex("\\s+"), " ").trim()
        if (t.length > 500) {
            val cut = t.lastIndexOf('.', 500)
            t = if (cut > 100) t.substring(0, cut + 1) else t.substring(0, 500)
        }
        return t
    }
}
