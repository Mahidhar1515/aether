package com.example.aether

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

enum class Phase { STARTING, IDLE, WAKE_LISTENING, LISTENING, THINKING, SPEAKING, ERROR }

data class ChatLine(val fromUser: Boolean, val text: String, val id: Long = System.nanoTime())

data class UiState(
    val phase: Phase = Phase.IDLE,
    val serviceRunning: Boolean = false,
    val wakeWordEnabled: Boolean = true,
    val partialText: String = "",
    val chat: List<ChatLine> = emptyList(),
    val facts: List<String> = emptyList(),
    val voskModelReady: Boolean = false,
    val llmModelReady: Boolean = false,
    val llmLoaded: Boolean = false,
    val llmError: String = "",
    val statusNote: String = "",
    val modelDir: String = "",
    val importNote: String = "",
    val importing: Boolean = false
)

/** Single in-process channel between the background service and the UI. */
object AetherBus {
    private val _state = MutableStateFlow(UiState())
    val state: StateFlow<UiState> = _state.asStateFlow()

    fun update(block: (UiState) -> UiState) {
        _state.update(block)
    }
}
