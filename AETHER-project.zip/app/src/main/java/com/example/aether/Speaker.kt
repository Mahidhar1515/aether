package com.example.aether

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/** Text-to-speech wrapper: deep, calm voice, prefers locally installed (offline) voices. */
class Speaker(context: Context) {
    private val main = Handler(Looper.getMainLooper())
    private var tts: TextToSpeech? = null
    private var ready = false
    private var failed = false
    private var pending: Pair<String, () -> Unit>? = null
    private var current: (() -> Unit)? = null

    init {
        tts = TextToSpeech(context.applicationContext) { status ->
            main.post {
                if (status == TextToSpeech.SUCCESS) {
                    configure()
                } else {
                    failed = true
                    val p = pending
                    pending = null
                    p?.second?.invoke()
                }
            }
        }
    }

    private fun configure() {
        val t = tts ?: return
        t.language = Locale.US
        t.setPitch(0.78f)
        t.setSpeechRate(0.95f)
        try {
            val voices = t.voices?.filter {
                it.locale.language == "en" && !it.isNetworkConnectionRequired
            } ?: emptyList()
            val preferred = voices.firstOrNull {
                it.name.contains("en-us-x-iom") || it.name.contains("en-us-x-iol") ||
                    it.name.contains("en-gb-x-rjs")
            } ?: voices.firstOrNull {
                it.name.contains("male", true) && !it.name.contains("female", true)
            }
            if (preferred != null) t.voice = preferred
        } catch (_: Exception) {
        }
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) = finish()

            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) = finish()
            override fun onError(utteranceId: String?, errorCode: Int) = finish()
        })
        ready = true
        val p = pending
        pending = null
        if (p != null) speak(p.first, p.second)
    }

    private fun finish() {
        main.post {
            val cb = current
            current = null
            cb?.invoke()
        }
    }

    fun speak(text: String, onDone: () -> Unit) {
        val t = tts
        if (failed || t == null) {
            onDone()
            return
        }
        if (!ready) {
            pending = text to onDone
            return
        }
        current = onDone
        val r = t.speak(text.take(3500), TextToSpeech.QUEUE_FLUSH, null, "aether-${System.nanoTime()}")
        if (r != TextToSpeech.SUCCESS) finish()
    }

    fun stop() {
        tts?.stop()
        finish()
    }

    fun shutdown() {
        try {
            tts?.stop()
            tts?.shutdown()
        } catch (_: Exception) {
        }
    }
}
