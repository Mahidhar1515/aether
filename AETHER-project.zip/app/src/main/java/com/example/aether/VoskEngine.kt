package com.example.aether

import android.content.Context
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener
import org.vosk.android.SpeechService
import java.io.File

/**
 * Fully offline speech recognition (Vosk).
 * Model folder: <externalFilesDir>/vosk-model  (contents of vosk-model-small-en-us-0.15)
 */
class VoskEngine(private val context: Context) {
    private var model: Model? = null
    private var service: SpeechService? = null
    private var token = 0

    companion object {
        private const val SAMPLE_RATE = 16000f
        // "Hey AETHER" sounds like "hey ether"; "aether" is not in the small model vocabulary.
        private const val WAKE_GRAMMAR = """["hey ether", "hey either", "hey eether", "[unk]"]"""
    }

    fun externalRoot(): File = context.getExternalFilesDir(null) ?: context.filesDir

    private fun looksLikeModel(d: File) = File(d, "am").isDirectory && File(d, "conf").isDirectory

    private fun findModelDir(): File? {
        val root = File(externalRoot(), "vosk-model")
        if (looksLikeModel(root)) return root
        return root.listFiles()?.firstOrNull { it.isDirectory && looksLikeModel(it) }
    }

    /** Blocking. Returns null on success, or an error message. */
    fun loadModel(): String? {
        return try {
            try { model?.close() } catch (_: Throwable) {}
            model = null
            val dir = findModelDir()
                ?: return "Speech model not found. Put the Vosk model in: ${File(externalRoot(), "vosk-model").absolutePath}"
            model = Model(dir.absolutePath)
            null
        } catch (t: Throwable) {
            "Could not load speech model: ${t.message ?: t.javaClass.simpleName}"
        }
    }

    fun startWake(onHeard: () -> Unit, onFail: (String) -> Unit) {
        stop()
        val m = model ?: return onFail("Speech model not loaded")
        val my = ++token
        try {
            val rec = Recognizer(m, SAMPLE_RATE, WAKE_GRAMMAR)
            val s = SpeechService(rec, SAMPLE_RATE)
            service = s
            var fired = false
            fun check(text: String) {
                if (fired || my != token) return
                if (text.contains("hey") &&
                    (text.contains("ether") || text.contains("either") || text.contains("eether"))
                ) {
                    fired = true
                    onHeard()
                }
            }
            s.startListening(object : RecognitionListener {
                override fun onPartialResult(hypothesis: String?) = check(field(hypothesis, "partial"))
                override fun onResult(hypothesis: String?) = check(field(hypothesis, "text"))
                override fun onFinalResult(hypothesis: String?) = check(field(hypothesis, "text"))
                override fun onError(exception: Exception?) {
                    if (my == token) onFail(exception?.message ?: "Microphone error")
                }

                override fun onTimeout() {}
            })
        } catch (t: Throwable) {
            onFail("Microphone/recognizer error: ${t.message ?: t.javaClass.simpleName}")
        }
    }

    fun startCommand(onPartial: (String) -> Unit, onFinal: (String) -> Unit, onFail: (String) -> Unit) {
        stop()
        val m = model ?: return onFail("Speech model not loaded")
        val my = ++token
        try {
            val rec = Recognizer(m, SAMPLE_RATE)
            val s = SpeechService(rec, SAMPLE_RATE)
            service = s
            var done = false
            fun finish(text: String) {
                if (done || my != token) return
                done = true
                onFinal(text)
            }
            s.startListening(object : RecognitionListener {
                override fun onPartialResult(hypothesis: String?) {
                    if (!done && my == token) onPartial(field(hypothesis, "partial"))
                }

                override fun onResult(hypothesis: String?) {
                    val t = field(hypothesis, "text")
                    if (t.isNotBlank()) finish(t)
                }

                override fun onFinalResult(hypothesis: String?) = finish(field(hypothesis, "text"))
                override fun onError(exception: Exception?) {
                    if (my == token && !done) {
                        done = true
                        onFail(exception?.message ?: "Microphone error")
                    }
                }

                override fun onTimeout() = finish("")
            }, 12000)
        } catch (t: Throwable) {
            onFail("Microphone/recognizer error: ${t.message ?: t.javaClass.simpleName}")
        }
    }

    fun stop() {
        token++
        val s = service ?: return
        service = null
        try {
            s.stop()
            s.shutdown()
        } catch (_: Throwable) {
        }
    }

    fun shutdown() {
        stop()
        try {
            model?.close()
        } catch (_: Throwable) {
        }
        model = null
    }

    private fun field(json: String?, key: String): String =
        try {
            JSONObject(json ?: "{}").optString(key, "").trim()
        } catch (_: Exception) {
            ""
        }
}
