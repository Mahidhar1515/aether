package com.example.aether

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Foreground (microphone) service that owns the whole assistant:
 * wake word -> listen -> think -> speak -> back to wake word.
 * Keeps working with the screen locked.
 */
class AetherService : Service() {

    companion object {
        const val ACTION_START = "com.example.aether.START"
        const val ACTION_STOP = "com.example.aether.STOP"
        const val ACTION_TALK = "com.example.aether.TALK"
        const val ACTION_TEXT = "com.example.aether.TEXT"
        const val ACTION_WAKE = "com.example.aether.WAKE"
        const val ACTION_DELETE_FACT = "com.example.aether.DELETE_FACT"
        const val ACTION_CLEAR_MEMORY = "com.example.aether.CLEAR_MEMORY"
        const val ACTION_RELOAD = "com.example.aether.RELOAD"
        private const val CHANNEL = "aether_listening"
        private const val NOTIF_ID = 42

        fun send(ctx: Context, action: String, extras: Intent.() -> Unit = {}) {
            val i = Intent(ctx, AetherService::class.java).setAction(action).apply(extras)
            ContextCompat.startForegroundService(ctx, i)
        }
    }

    private val main = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    private lateinit var memory: MemoryStore
    private lateinit var brain: LocalBrain
    private lateinit var vosk: VoskEngine
    private var speaker: Speaker? = null
    private var wakeLock: PowerManager.WakeLock? = null

    private var dead = false
    private var ready = false
    private var busy = false
    private var wakeEnabled = true
    private var greeted = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val channel = NotificationChannel(CHANNEL, "AETHER", NotificationManager.IMPORTANCE_LOW)
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        try {
            val n = buildNotification("Starting…")
            if (Build.VERSION.SDK_INT >= 30) {
                startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
            } else {
                startForeground(NOTIF_ID, n)
            }
        } catch (t: Throwable) {
            dead = true
            AetherBus.update {
                it.copy(
                    serviceRunning = false, phase = Phase.ERROR,
                    statusNote = "Could not start microphone service: ${t.message}. Grant microphone permission and retry."
                )
            }
            stopSelf()
            return
        }

        memory = MemoryStore(this)
        brain = LocalBrain(this, memory)
        vosk = VoskEngine(this)
        speaker = Speaker(this)
        wakeEnabled = getSharedPreferences("aether", MODE_PRIVATE).getBoolean("wake", true)

        try {
            val pm = getSystemService(POWER_SERVICE) as PowerManager
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "aether:listen").also { it.acquire() }
        } catch (_: Throwable) {
        }

        AetherBus.update {
            it.copy(
                serviceRunning = true, phase = Phase.STARTING, wakeWordEnabled = wakeEnabled,
                facts = memory.facts(), modelDir = vosk.externalRoot().absolutePath, statusNote = ""
            )
        }

        initEngines()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (dead) return START_NOT_STICKY
        when (intent?.action) {
            ACTION_STOP -> {
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
            ACTION_TALK -> onTalk()
            ACTION_TEXT -> intent?.getStringExtra("text")?.let { onTyped(it) }
            ACTION_WAKE -> onWakeToggle(intent?.getBooleanExtra("enabled", true) ?: true)
            ACTION_DELETE_FACT -> {
                memory.removeFact(intent?.getIntExtra("index", -1) ?: -1)
                publishFacts()
            }
            ACTION_RELOAD -> initEngines()
            ACTION_CLEAR_MEMORY -> {
                memory.clearAll()
                publishFacts()
            }
        }
        return START_STICKY
    }

    private fun initEngines() {
        scope.launch {
            withContext(Dispatchers.Main) {
                ready = false
                busy = true
                vosk.stop()
                setPhase(Phase.STARTING)
            }
            val voskErr = vosk.loadModel()
            withContext(Dispatchers.Main) {
                ready = voskErr == null
                AetherBus.update { it.copy(voskModelReady = ready) }
                if (voskErr != null) {
                    busy = false
                    setPhase(Phase.ERROR, voskErr)
                } else if (!greeted) {
                    greeted = true
                    busy = true
                    greet()
                } else {
                    enterIdle()
                }
            }
            val llmErr = brain.loadLlm()
            AetherBus.update {
                it.copy(llmModelReady = brain.hasModelFile(), llmLoaded = llmErr == null, llmError = llmErr ?: "")
            }
        }
    }

    // ------------------------------------------------------------ conversation flow (main thread)

    private fun greet() {
        val msg = "I'm here, ${memory.userName()}. AETHER is ready."
        addChat(false, msg)
        setPhase(Phase.SPEAKING)
        speaker?.speak(msg) { enterIdle() }
    }

    private fun enterIdle() {
        busy = false
        if (!ready) {
            setPhase(Phase.IDLE)
            return
        }
        if (wakeEnabled) startWake() else {
            vosk.stop()
            setPhase(Phase.IDLE)
        }
    }

    private fun startWake() {
        setPhase(Phase.WAKE_LISTENING)
        vosk.startWake(
            onHeard = { beginCommand() },
            onFail = { msg -> fail(msg) }
        )
    }

    private fun beginCommand() {
        if (!ready) return
        busy = true
        vosk.stop()
        beep()
        setPhase(Phase.LISTENING)
        main.postDelayed({
            if (!busy || AetherBus.state.value.phase != Phase.LISTENING) return@postDelayed
            vosk.startCommand(
                onPartial = { p -> AetherBus.update { it.copy(partialText = p) } },
                onFinal = { text -> if (text.isBlank()) enterIdle() else handleUtterance(text) },
                onFail = { msg -> fail(msg) }
            )
        }, 250)
    }

    private fun handleUtterance(text: String) {
        vosk.stop()
        busy = true
        addChat(true, text)
        setPhase(Phase.THINKING)
        scope.launch {
            val reply = try {
                brain.respond(text)
            } catch (t: Throwable) {
                "Sorry, something went wrong. ${t.message ?: ""}".trim()
            }
            withContext(Dispatchers.Main) {
                publishFacts()
                addChat(false, reply)
                setPhase(Phase.SPEAKING)
                speaker?.speak(reply) { enterIdle() }
            }
        }
    }

    private fun onTalk() {
        if (busy) {
            when (AetherBus.state.value.phase) {
                Phase.SPEAKING -> speaker?.stop()
                Phase.LISTENING -> {
                    vosk.stop()
                    enterIdle()
                }
                else -> {}
            }
            return
        }
        beginCommand()
    }

    private fun onTyped(text: String) {
        if (text.isBlank() || busy) return
        handleUtterance(text.trim())
    }

    private fun onWakeToggle(enabled: Boolean) {
        wakeEnabled = enabled
        getSharedPreferences("aether", MODE_PRIVATE).edit().putBoolean("wake", enabled).apply()
        AetherBus.update { it.copy(wakeWordEnabled = enabled) }
        if (!busy && ready) enterIdle()
    }

    private fun fail(msg: String) {
        vosk.stop()
        busy = false
        setPhase(Phase.ERROR, msg)
    }

    // ------------------------------------------------------------ helpers

    private fun publishFacts() {
        AetherBus.update { it.copy(facts = memory.facts()) }
    }

    private fun addChat(fromUser: Boolean, text: String) {
        AetherBus.update { it.copy(chat = (it.chat + ChatLine(fromUser, text)).takeLast(60)) }
    }

    private fun setPhase(p: Phase, note: String? = null) {
        AetherBus.update {
            it.copy(phase = p, partialText = "", statusNote = note ?: if (p == Phase.ERROR) it.statusNote else "")
        }
        val label = when (p) {
            Phase.STARTING -> "Starting…"
            Phase.IDLE -> "Idle"
            Phase.WAKE_LISTENING -> "Listening for “Hey Ether”"
            Phase.LISTENING -> "Listening…"
            Phase.THINKING -> "Thinking…"
            Phase.SPEAKING -> "Speaking…"
            Phase.ERROR -> "Needs attention"
        }
        try {
            getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification(label))
        } catch (_: Throwable) {
        }
    }

    private fun beep() {
        try {
            val tg = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 60)
            tg.startTone(ToneGenerator.TONE_PROP_BEEP, 120)
            main.postDelayed({ tg.release() }, 400)
        } catch (_: Throwable) {
        }
    }

    private fun buildNotification(text: String): Notification {
        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), flags)
        val stop = PendingIntent.getService(
            this, 1, Intent(this, AetherService::class.java).setAction(ACTION_STOP), flags
        )
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("AETHER")
            .setContentText(text)
            .setContentIntent(open)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .addAction(0, "Stop", stop)
            .build()
    }

    override fun onDestroy() {
        if (!dead) {
            scope.cancel()
            try {
                vosk.shutdown()
            } catch (_: Throwable) {
            }
            speaker?.shutdown()
            brain.close()
            try {
                wakeLock?.let { if (it.isHeld) it.release() }
            } catch (_: Throwable) {
            }
        }
        AetherBus.update { it.copy(serviceRunning = false, phase = Phase.IDLE, partialText = "") }
        super.onDestroy()
    }
}
