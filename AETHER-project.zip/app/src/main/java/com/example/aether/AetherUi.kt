package com.example.aether

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.PI
import kotlin.math.sin

private val BgColor = Color(0xFF05080F)
private val Panel = Color(0xFF0C1422)
private val Cyan = Color(0xFF00E5FF)
private val Violet = Color(0xFF7C4DFF)
private val Dim = Color(0xFF7F93AD)
private val Good = Color(0xFF69F0AE)
private val Bad = Color(0xFFFF5252)
private val TextMain = Color(0xFFE6F1FF)

@Composable
fun AetherTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Cyan, onPrimary = Color.Black,
            background = BgColor, surface = Panel, onSurface = TextMain
        ),
        content = content
    )
}

@Composable
fun AetherScreen(onRequestStart: () -> Unit) {
    val ctx = LocalContext.current
    val ui by AetherBus.state.collectAsState()
    var tab by remember { mutableStateOf(0) }
    var input by remember { mutableStateOf("") }

    fun sendTyped() {
        val t = input.trim()
        if (t.isEmpty()) return
        if (!ui.serviceRunning) {
            onRequestStart()
            return
        }
        AetherService.send(ctx, AetherService.ACTION_TEXT) { putExtra("text", t) }
        input = ""
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(BgColor)
            .systemBarsPadding()
            .imePadding()
            .padding(horizontal = 16.dp)
    ) {
        // Header
        Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("AETHER", color = Cyan, fontSize = 22.sp, fontWeight = FontWeight.Bold, letterSpacing = 6.sp)
            Spacer(Modifier.weight(1f))
            Text("Wake word", color = Dim, fontSize = 12.sp)
            Spacer(Modifier.width(8.dp))
            Switch(
                checked = ui.wakeWordEnabled,
                onCheckedChange = { enabled ->
                    AetherService.send(ctx, AetherService.ACTION_WAKE) { putExtra("enabled", enabled) }
                },
                enabled = ui.serviceRunning
            )
        }

        // Orb
        Box(Modifier.fillMaxWidth().padding(top = 8.dp), contentAlignment = Alignment.Center) {
            Orb(ui.phase) {
                if (!ui.serviceRunning) onRequestStart()
                else AetherService.send(ctx, AetherService.ACTION_TALK)
            }
        }
        Text(
            if (!ui.serviceRunning) "Offline — tap the orb to start" else phaseLabel(ui.phase),
            color = if (ui.phase == Phase.ERROR) Bad else Cyan,
            modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center, fontSize = 14.sp
        )
        Text(
            if (ui.phase == Phase.ERROR) ui.statusNote else ui.partialText,
            color = if (ui.phase == Phase.ERROR) Bad else Dim,
            modifier = Modifier.fillMaxWidth().height(40.dp).padding(top = 4.dp),
            textAlign = TextAlign.Center, fontSize = 13.sp, maxLines = 2
        )

        // Tabs
        Row(Modifier.fillMaxWidth()) {
            listOf("CHAT", "MEMORY", "SETUP").forEachIndexed { i, label ->
                TextButton(onClick = { tab = i }, modifier = Modifier.weight(1f)) {
                    Text(
                        label,
                        color = if (tab == i) Cyan else Dim,
                        fontWeight = if (tab == i) FontWeight.Bold else FontWeight.Normal,
                        letterSpacing = 2.sp, fontSize = 12.sp
                    )
                }
            }
        }

        Box(Modifier.weight(1f).fillMaxWidth()) {
            when (tab) {
                0 -> ChatTab(ui.chat)
                1 -> MemoryTab(ui.facts, ui.serviceRunning)
                else -> SetupTab(ui, onRequestStart)
            }
        }

        // Input bar
        Row(
            Modifier.fillMaxWidth().padding(vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Type a message…", color = Dim) },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = { sendTyped() })
            )
            Spacer(Modifier.width(8.dp))
            Button(onClick = { sendTyped() }) { Text("SEND") }
            Spacer(Modifier.width(6.dp))
            OutlinedButton(onClick = {
                if (!ui.serviceRunning) onRequestStart()
                else AetherService.send(ctx, AetherService.ACTION_TALK)
            }) { Text("TALK") }
        }
    }
}

private fun phaseLabel(p: Phase) = when (p) {
    Phase.STARTING -> "Starting…"
    Phase.IDLE -> "Idle — tap the orb to talk"
    Phase.WAKE_LISTENING -> "Listening for “Hey Ether”"
    Phase.LISTENING -> "Listening…"
    Phase.THINKING -> "Thinking…"
    Phase.SPEAKING -> "Speaking — tap to interrupt"
    Phase.ERROR -> "Needs attention — see Setup"
}

@Composable
private fun Orb(phase: Phase, onClick: () -> Unit) {
    val t by rememberInfiniteTransition(label = "orb").animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1600, easing = LinearEasing), RepeatMode.Restart),
        label = "t"
    )
    val color = when (phase) {
        Phase.ERROR -> Bad
        Phase.THINKING -> Violet
        Phase.IDLE, Phase.STARTING -> Dim
        else -> Cyan
    }
    val amp = when (phase) {
        Phase.SPEAKING -> 0.12f
        Phase.LISTENING -> 0.09f
        Phase.WAKE_LISTENING -> 0.035f
        Phase.THINKING -> 0.04f
        else -> 0.015f
    }
    Canvas(
        Modifier
            .size(190.dp)
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onClick)
    ) {
        val c = center
        val base = size.minDimension / 2f
        val wave = sin(t * 2f * PI.toFloat())
        drawCircle(color.copy(alpha = 0.10f), radius = base * (0.97f + amp * wave), center = c)
        drawCircle(color.copy(alpha = 0.20f), radius = base * (0.80f + amp * 0.7f * wave), center = c)
        drawCircle(
            Brush.radialGradient(listOf(color.copy(alpha = 0.55f), color.copy(alpha = 0.05f)), center = c, radius = base * 0.58f),
            radius = base * 0.58f, center = c
        )
        drawCircle(color, radius = base * 0.58f, center = c, style = Stroke(width = 3.dp.toPx()))
        if (phase == Phase.THINKING) {
            drawArc(
                color = color, startAngle = t * 360f, sweepAngle = 100f, useCenter = false,
                topLeft = Offset(c.x - base * 0.75f, c.y - base * 0.75f),
                size = Size(base * 1.5f, base * 1.5f),
                style = Stroke(width = 4.dp.toPx(), cap = StrokeCap.Round)
            )
        }
    }
}

@Composable
private fun ChatTab(chat: List<ChatLine>) {
    val listState = rememberLazyListState()
    LaunchedEffect(chat.size) {
        if (chat.isNotEmpty()) listState.animateScrollToItem(chat.size - 1)
    }
    if (chat.isEmpty()) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text(
                "Say “Hey Ether”, tap the orb, or type below.",
                color = Dim, textAlign = TextAlign.Center
            )
        }
    } else {
        LazyColumn(
            state = listState,
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(chat, key = { it.id }) { line ->
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = if (line.fromUser) Arrangement.End else Arrangement.Start
                ) {
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = if (line.fromUser) Cyan.copy(alpha = 0.16f) else Panel,
                        modifier = Modifier.widthIn(max = 300.dp)
                    ) {
                        Text(line.text, color = TextMain, modifier = Modifier.padding(12.dp), fontSize = 14.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun MemoryTab(facts: List<String>, running: Boolean) {
    val ctx = LocalContext.current
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("Stored only on this device", color = Dim, fontSize = 12.sp, modifier = Modifier.weight(1f))
            TextButton(
                onClick = { AetherService.send(ctx, AetherService.ACTION_CLEAR_MEMORY) },
                enabled = running && facts.isNotEmpty()
            ) { Text("CLEAR ALL", color = Bad, fontSize = 12.sp) }
        }
        if (facts.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Nothing saved yet.\nSay “remember that …” to add a note.", color = Dim, textAlign = TextAlign.Center)
            }
        } else {
            LazyColumn(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                itemsIndexed(facts) { i, fact ->
                    Surface(shape = RoundedCornerShape(12.dp), color = Panel) {
                        Row(Modifier.fillMaxWidth().padding(start = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(fact, color = TextMain, modifier = Modifier.weight(1f), fontSize = 14.sp)
                            TextButton(onClick = {
                                AetherService.send(ctx, AetherService.ACTION_DELETE_FACT) { putExtra("index", i) }
                            }) { Text("DELETE", color = Bad, fontSize = 11.sp) }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SetupTab(ui: UiState, onRequestStart: () -> Unit) {
    val ctx = LocalContext.current
    val voskPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) ModelImporter.importVosk(ctx, uri)
    }
    val llmPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) ModelImporter.importLlm(ctx, uri)
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        StatusRow("Speech model (Vosk)", ui.voskModelReady)
        StatusRow("Language model file found", ui.llmModelReady)
        StatusRow("Language model loaded", ui.llmLoaded)
        if (ui.llmError.isNotBlank()) Text("LLM: ${ui.llmError}", color = Bad, fontSize = 12.sp)
        if (ui.statusNote.isNotBlank()) Text(ui.statusNote, color = Bad, fontSize = 12.sp)

        Surface(shape = RoundedCornerShape(12.dp), color = Panel) {
            Text(
                "One-time setup, no computer needed:\n\n" +
                    "1. In your phone browser, download:\n" +
                    "   • Speech model: alphacephei.com/vosk/models → vosk-model-small-en-us-0.15.zip\n" +
                    "   • Language model: a .task file from huggingface.co/litert-community (e.g. Gemma 3 1B IT int4)\n\n" +
                    "2. Tap the import buttons below and pick each downloaded file.\n\n" +
                    "After that AETHER works fully offline.",
                color = Dim, fontSize = 12.sp, modifier = Modifier.padding(12.dp)
            )
        }

        if (ui.importNote.isNotBlank()) {
            Text(ui.importNote, color = if (ui.importNote.contains("failed")) Bad else Cyan, fontSize = 12.sp)
        }
        Button(
            onClick = { voskPicker.launch(arrayOf("*/*")) },
            enabled = !ui.importing,
            modifier = Modifier.fillMaxWidth()
        ) { Text("IMPORT SPEECH MODEL (.zip)") }
        Button(
            onClick = { llmPicker.launch(arrayOf("*/*")) },
            enabled = !ui.importing,
            modifier = Modifier.fillMaxWidth()
        ) { Text("IMPORT LANGUAGE MODEL (.task)") }

        OutlinedButton(onClick = {
            try {
                ctx.startActivity(
                    Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:${ctx.packageName}"))
                )
            } catch (_: Exception) {
                ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }
        }, modifier = Modifier.fillMaxWidth()) { Text("ALLOW BACKGROUND / LOCKED-SCREEN USE") }

        if (ui.serviceRunning) {
            OutlinedButton(
                onClick = { AetherService.send(ctx, AetherService.ACTION_STOP) },
                modifier = Modifier.fillMaxWidth()
            ) { Text("STOP AETHER", color = Bad) }
        } else {
            Button(onClick = onRequestStart, modifier = Modifier.fillMaxWidth()) { Text("START AETHER") }
        }
        Spacer(Modifier.height(12.dp))
    }
}

@Composable
private fun StatusRow(label: String, ok: Boolean) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = TextMain, modifier = Modifier.weight(1f), fontSize = 14.sp)
        Text(if (ok) "READY" else "MISSING", color = if (ok) Good else Bad, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
}
