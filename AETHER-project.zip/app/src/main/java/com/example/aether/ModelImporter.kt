package com.example.aether

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import java.io.File
import java.util.zip.ZipInputStream
import kotlin.concurrent.thread

/** Imports the two model files from anywhere on the phone (Downloads etc.) into the app's private folder. */
object ModelImporter {

    private fun root(ctx: Context): File = ctx.getExternalFilesDir(null) ?: ctx.filesDir

    private fun note(text: String, importing: Boolean) {
        AetherBus.update { it.copy(importNote = text, importing = importing) }
    }

    private fun reloadIfRunning(ctx: Context) {
        if (AetherBus.state.value.serviceRunning) {
            try {
                AetherService.send(ctx, AetherService.ACTION_RELOAD)
            } catch (_: Throwable) {
                note("Imported. Close and reopen AETHER to load it.", false)
            }
        }
    }

    fun importVosk(context: Context, uri: Uri) {
        val ctx = context.applicationContext
        if (AetherBus.state.value.importing) return
        note("Importing speech model…", true)
        thread(name = "import-vosk") {
            try {
                val dest = File(root(ctx), "vosk-model")
                dest.deleteRecursively()
                dest.mkdirs()
                val destCanon = dest.canonicalPath + File.separator
                var count = 0
                val input = ctx.contentResolver.openInputStream(uri) ?: throw IllegalStateException("Cannot open file")
                input.use { raw ->
                    ZipInputStream(raw.buffered()).use { zip ->
                        var e = zip.nextEntry
                        while (e != null) {
                            val out = File(dest, e.name)
                            if (!out.canonicalPath.startsWith(destCanon)) throw SecurityException("Bad zip entry")
                            if (e.isDirectory) {
                                out.mkdirs()
                            } else {
                                out.parentFile?.mkdirs()
                                out.outputStream().use { zip.copyTo(it) }
                                count++
                                if (count % 20 == 0) note("Importing speech model… $count files", true)
                            }
                            e = zip.nextEntry
                        }
                    }
                }
                if (count == 0) throw IllegalStateException("That file is not a zip archive or is empty")
                note("Speech model imported ($count files).", false)
                reloadIfRunning(ctx)
            } catch (t: Throwable) {
                note("Speech model import failed: ${t.message ?: t.javaClass.simpleName}", false)
            }
        }
    }

    fun importLlm(context: Context, uri: Uri) {
        val ctx = context.applicationContext
        if (AetherBus.state.value.importing) return
        note("Importing language model…", true)
        thread(name = "import-llm") {
            try {
                val dir = File(root(ctx), "models")
                dir.mkdirs()
                dir.listFiles()?.forEach { f -> if (f.isFile) f.delete() }
                var name = displayName(ctx, uri).replace(Regex("[^A-Za-z0-9._-]"), "_")
                if (!name.endsWith(".task", ignoreCase = true)) name += ".task"
                val tmp = File(dir, "$name.part")
                var total = 0L
                var lastNote = 0L
                val input = ctx.contentResolver.openInputStream(uri) ?: throw IllegalStateException("Cannot open file")
                input.use { inp ->
                    tmp.outputStream().use { out ->
                        val buf = ByteArray(1 shl 20)
                        while (true) {
                            val n = inp.read(buf)
                            if (n < 0) break
                            out.write(buf, 0, n)
                            total += n
                            if (total - lastNote > 25L * 1024 * 1024) {
                                lastNote = total
                                note("Importing language model… ${total / 1048576} MB", true)
                            }
                        }
                    }
                }
                if (!tmp.renameTo(File(dir, name))) throw IllegalStateException("Could not save model file")
                note("Language model imported (${total / 1048576} MB). Loading…", false)
                reloadIfRunning(ctx)
            } catch (t: Throwable) {
                note("Language model import failed: ${t.message ?: t.javaClass.simpleName}", false)
            }
        }
    }

    private fun displayName(ctx: Context, uri: Uri): String =
        try {
            ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getString(0) else null
            } ?: "model.task"
        } catch (_: Throwable) {
            "model.task"
        }
}
