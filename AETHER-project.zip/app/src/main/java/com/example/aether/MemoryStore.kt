package com.example.aether

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Local, private memory: saved facts plus a short rolling conversation history. */
class MemoryStore(context: Context) {
    private val file = File(context.filesDir, "aether_memory.json")
    private val facts = mutableListOf<String>()
    private val turns = mutableListOf<Pair<String, String>>()
    private var name = "Mahidhar"

    init {
        load()
    }

    @Synchronized fun userName(): String = name

    @Synchronized fun setUserName(n: String) {
        val t = n.trim()
        if (t.isNotEmpty()) {
            name = t
            save()
        }
    }

    @Synchronized fun facts(): List<String> = facts.toList()

    @Synchronized fun addFact(text: String) {
        val t = text.trim().trimEnd('.', '!', '?')
        if (t.isNotEmpty() && facts.none { it.equals(t, ignoreCase = true) }) {
            facts.add(t)
            save()
        }
    }

    @Synchronized fun removeFact(index: Int) {
        if (index in facts.indices) {
            facts.removeAt(index)
            save()
        }
    }

    @Synchronized fun clearAll() {
        facts.clear()
        turns.clear()
        save()
    }

    @Synchronized fun addTurn(user: String, assistant: String) {
        turns.add(user to assistant)
        while (turns.size > 20) turns.removeAt(0)
        save()
    }

    @Synchronized fun recentTurns(n: Int): List<Pair<String, String>> = turns.takeLast(n)

    private fun load() {
        try {
            if (!file.exists()) return
            val o = JSONObject(file.readText())
            name = o.optString("name", name)
            val f = o.optJSONArray("facts") ?: JSONArray()
            for (i in 0 until f.length()) facts.add(f.getString(i))
            val t = o.optJSONArray("turns") ?: JSONArray()
            for (i in 0 until t.length()) {
                val x = t.getJSONObject(i)
                turns.add(x.getString("u") to x.getString("a"))
            }
        } catch (_: Exception) {
        }
    }

    private fun save() {
        try {
            val o = JSONObject()
            o.put("name", name)
            val f = JSONArray()
            facts.forEach { f.put(it) }
            o.put("facts", f)
            val t = JSONArray()
            turns.forEach { t.put(JSONObject().put("u", it.first).put("a", it.second)) }
            o.put("turns", t)
            file.writeText(o.toString())
        } catch (_: Exception) {
        }
    }
}
