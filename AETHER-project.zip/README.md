# AETHER — get the APK without Android Studio

GitHub builds the app for you in the cloud (free). About 15 minutes total.

## A. Build the APK
1. Create a free account at github.com, then click **+ → New repository**. Name it `aether`, set it to **Private**, click **Create repository**.
2. Unzip AETHER-project.zip on your computer.
3. On the new repo page click **uploading an existing file**. Drag in everything inside the unzipped folder
   (`app` folder, `build.gradle.kts`, `settings.gradle.kts`, `gradle.properties`, `.gitignore`), then **Commit changes**.
4. The build recipe lives in a hidden folder, so add it by hand:
   **Add file → Create new file**, type the name exactly `.github/workflows/build.yml`
   (typing the slashes creates the folders), paste the contents of `build.yml` from the zip, **Commit changes**.
5. Open the **Actions** tab. The "Build AETHER APK" run starts by itself (first build ~5–8 min). Wait for the green tick.
   If it is red, open it and send me the log text; I will fix it in one go.
6. Click the finished run, scroll to **Artifacts**, download **AETHER-debug-apk** (a zip), unzip it to get `app-debug.apk`.

## B. Install on the OnePlus 13R
1. Send `app-debug.apk` to the phone (USB, Google Drive, WhatsApp to yourself...).
2. Open it. Allow "Install unknown apps" for that app when asked, then Install.

## C. One-time model setup (on the phone, no computer)
1. Open AETHER and allow the microphone and notifications.
2. In the phone browser, download:
   - Speech model: https://alphacephei.com/vosk/models/vosk-model-small-en-us-0.15.zip
   - Language model: any MediaPipe `.task` file from huggingface.co/litert-community
     (e.g. Gemma 3 1B IT int4, needs a free account and licence acceptance; Qwen2.5 1.5B Instruct is an alternative).
3. In AETHER: **SETUP tab → IMPORT SPEECH MODEL**, pick the zip. Then **IMPORT LANGUAGE MODEL**, pick the .task file.
   It loads automatically. Both status rows turn READY.
4. Tap **ALLOW BACKGROUND / LOCKED-SCREEN USE**.

## D. Use it
Say "Hey Ether" (how "Hey AETHER" is recognised), or tap the orb / TALK, or type.
Try: "what time is it", "remember that ...", "what do you remember", "forget everything", or ask anything.
Tap the orb while it speaks to interrupt. Turn the wake word off with the header switch to save battery.
